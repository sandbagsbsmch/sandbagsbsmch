public class Variables {
    public static void main(String[] args) {
        
        // Stage 1
        int x = 200;
        double y = 5.1;
        char letter = 'r';
        char number = '51';
        String s = "hi";
        int a = 1.2;
        boolean b = 4;

        // Stage 2
        int myAge = 21;

        // Stage 3
        String myName = "Jech ineyney";

        // Stage 4
        double myWeight = 60.3;
    }
}
