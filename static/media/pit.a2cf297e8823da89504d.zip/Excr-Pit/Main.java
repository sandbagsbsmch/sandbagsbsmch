package com.company;


import java.util.Scanner;


public class Main {


    public static void main(String[] args) {


// 1

        Scanner input = new Scanner(System.in);


        System.out.println("Enter number:");

        int number = Integer.parseInt(input.nextLine());


        int unitsDigit = number % 10;


        int answer;

        if (unitsDigit >= 5) {

            answer = number + 10 - unitsDigit;

        } else {

            answer = number - unitsDigit;

        }


        System.out.println("The rounded answer is " + answer);


// 2

        Scanner input = new Scanner(System.in);


        System.out.println("Enter first number:");

        int firstNumber = Integer.parseInt(input.nextLine());


        System.out.println("Enter second number:");

        int secondNumber = Integer.parseInt(input.nextLine());


        if ((firstNumber % secondNumber) == 0 || (secondNumber % firstNumber) == 0) {

            System.out.println("Is factor");

        } else {

            System.out.println("Isnt factor");

        }


// 3

        Scanner input = new Scanner(System.in);


        System.out.println("Enter your grade");

        int grade = Integer.parseInt(input.nextLine());


        if (grade < 0) {

            System.out.println("Grade must be greater than 0");

        } else if (grade < 56) {

            System.out.println("Failed");

        } else if (grade < 70) {

            System.out.println("Almost enough");

        } else if (grade < 80) {

            System.out.println("Passable");

        } else if (grade < 90) {

            System.out.println("Good");

        } else if (grade < 95) {

            System.out.println("Very good");

        } else {

            System.out.println("Excellent");


            if (grade > 100) {

                System.out.println("You got " + (grade - 100) + " extra points");

            }

        }


// 4

        Scanner input = new Scanner(System.in);


        System.out.println("Enter museum capability:");

        int museumCapacity = Integer.parseInt(input.nextLine());


        System.out.println("Enter amount of groups:");

        int groupsAmount = Integer.parseInt(input.nextLine());


        System.out.println("Enter group size:");

        int groupSize = Integer.parseInt(input.nextLine());


        final int ESCORTS = 2;

        int requiredCapacity = groupsAmount * (groupSize + ESCORTS);


        if (requiredCapacity > museumCapacity) {

            System.out.println(

                    "Not enough space, "

                            + (requiredCapacity - museumCapacity)

                            + " + people don't have place");

        } else {

            System.out.println("There is enough place");

        }


// 5

        Scanner input = new Scanner(System.in);


        final int WINTER = 1;

        final int SPRING = 2;

        final int SUMMER = 3;

        final int FALL = 4;


        System.out.println("Enter average temperature: ");

        int averageTemperature = Integer.parseInt(input.nextLine());


        System.out.println("Enter season code: ");

        System.out.println(WINTER + " winter");

        System.out.println(SPRING + " spring");

        System.out.println(SUMMER + " summer");

        System.out.println(FALL + " fall");

        int yearCode = Integer.parseInt(input.nextLine());


        int expectedTemperature = averageTemperature;


        switch (yearCode) {

            case WINTER: {

                final int APPROVE = 1;

                final int DECLINE = 0;


                System.out.println("Is winter rainy?");

                System.out.println(APPROVE + " - yes");

                System.out.println(DECLINE + " - no");


                int answer = Integer.parseInt(input.nextLine());


                if (answer == APPROVE) {

                    expectedTemperature -= 7;

                } else {

                    expectedTemperature -= 5;

                }


                break;

            }

            case SPRING: {

                expectedTemperature *= 0.9;


                break;

            }

            case SUMMER: {

                System.out.println("Please enter humidity");

                int humidity = Integer.parseInt(input.nextLine());


                if (humidity < 60) {

                    expectedTemperature += 8;

                } else {

                    expectedTemperature += 12;

                }


                break;

            }

        }

        System.out.println(expectedTemperature);


// 6

        Scanner input = new Scanner(System.in);


        final int MIN_VALUE = 1;

        final int MAX_VALUE = 999;

        final int GAME_DIGIT = 7;


        System.out.println("Please enter number between " + MIN_VALUE + " and " + MAX_VALUE);


        int number = Integer.parseInt(input.nextLine());

        int digit = number % 10;

        int tens = (number / 10) % 10;

        int hundreds = number / 100;


        if ((number > MAX_VALUE) || (number < MIN_VALUE)) {

            System.out.println("Invalid input");

        } else if (((number % GAME_DIGIT) == 0)

                || (digit == GAME_DIGIT)

                || (tens == GAME_DIGIT)

                || (hundreds == GAME_DIGIT)) {

            System.out.println("BOOM");

        } else {

            System.out.println("NOT BOOM");

        }


        // 7

        final String COFFEE_ERROR = "You can't have the coffee, it is too strong for you";
        final String COFFEE_CONFIRMATION = "You can have the coffee, cheers!";

        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to Kety's cafe!");
        System.out.println("How many teaspoons of coffee do you want?");
        int coffeePowderTeaspoons = Integer.parseInt(scanner.nextLine());

        System.out.println("How many teaspoons of sugar do you want?");
        int sugarTeaspoons = Integer.parseInt(scanner.nextLine());

        System.out.println("Enter your chosen milk type: \n" +
                "1 - 1% milk \n" +
                "2- 2% milk \n" +
                "3- 3% milk");
        int milkFatPercentage = Integer.parseInt(scanner.nextLine());

        double strength = Math.pow(coffeePowderTeaspoons, 2) /
                (sugarTeaspoons * milkFatPercentage);

        System.out.println("The coffee's strength is: " + strength);

        System.out.println(COFFEE_ERROR);

        int age = Integer.parseInt(scanner.nextLine());

        if (age <= 15) {
            if (strength < 2 || strength == 2 && milkFatPercentage == 3) {
                System.out.println(COFFEE_CONFIRMATION);
            } else {
                System.out.println(COFFEE_ERROR);
            }
        } else if (age > 15 && age < 18) {
            if (strength < 4 && milkFatPercentage != 1) {
                System.out.println(COFFEE_CONFIRMATION);
            } else {
                System.out.println(COFFEE_ERROR);
            }
        } else {
            System.out.println(COFFEE_CONFIRMATION);
        }

        // For part b - add the following after the strength calculation
        double parameter = 1;

        switch (milkFatPercentage) {
            case 3:
                parameter = 0.5;

                break;

            case 2:
                parameter = 0.333;

                break;
            case 1:
                parameter = 0.25;

                break;

            default:
                break;
        }

        strength *= parameter;


        // Extra a

        Scanner input = new Scanner(System.in);

        int numberOfDaysInMonth = 0;
        String MonthOfName = "Unknown";

        System.out.print("Enter a month number: ");
        int month = input.nextInt();

        System.out.print("Enter a year: ");
        int year = input.nextInt();

        switch (month) {
            case 1:
                MonthOfName = "January";
                numberOfDaysInMonth = 31;

                break;


            case 2:
                MonthOfName = "February";

                if ((year % 400 == 0) || ((year % 4 == 0) && (year % 100 != 0))) {
                    numberOfDaysInMonth = 29;
                } else {
                    numberOfDaysInMonth = 28;
                }

                break;


            case 3:
                MonthOfName = "March";
                numberOfDaysInMonth = 31;

                break;


            case 4:
                MonthOfName = "April";
                numberOfDaysInMonth = 30;

                break;


            case 5:
                MonthOfName = "May";
                numberOfDaysInMonth = 31;

                break;


            case 6:
                MonthOfName = "June";
                numberOfDaysInMonth = 30;

                break;


            case 7:
                MonthOfName = "July";
                numberOfDaysInMonth = 31;

                break;


            case 8:
                MonthOfName = "August";
                numberOfDaysInMonth = 31;

                break;


            case 9:
                MonthOfName = "September";
                numberOfDaysInMonth = 30;

                break;


            case 10:
                MonthOfName = "October";
                numberOfDaysInMonth = 31;

                break;


            case 11:
                MonthOfName = "November";
                numberOfDaysInMonth = 30;

                break;


            case 12:
                MonthOfName = "December";
                numberOfDaysInMonth = 31;
        }

        System.out.print(MonthOfName + " " + year + " has " + numberOfDaysInMonth + " days\n");


// Extra b

        Scanner input = new Scanner(System.in);

        System.out.print("Input a: ");

        double firstNumber = Double.parseDouble(input.nextLine());

        input.nextLine();

        System.out.println(firstNumber);

        System.out.print("Input b: ");

        double secondNumber = Double.parseDouble(input.nextLine());

        System.out.println(secondNumber);

        System.out.print("Input c: ");

        double thirdNumber = Double.parseDouble(input.nextLine());

        System.out.println(thirdNumber);

        double result = secondNumber * secondNumber - 4.0 * firstNumber * thirdNumber;

        if (result > 0.0) {

            double firstRoot = (-secondNumber + Math.pow(result, 0.5)) / (2.0 * firstNumber);

            double secondRoot = (-secondNumber - Math.pow(result, 0.5)) / (2.0 * firstNumber);

            System.out.println("The roots are " + firstRoot + " and " + secondRoot);

        } else if (result == 0.0) {

            double firstRoot = -secondNumber / (2.0 * firstNumber);

            System.out.println("The root is " + firstRoot);

        } else {
            System.out.println("The equation has no real roots.");
        }
    }
}












