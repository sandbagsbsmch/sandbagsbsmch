import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in); 
 
        /*
            question 1:
        */        
        System.out.println("Enter numbers (-999 to stop):"); 
        int number = in.nextInt(); 
        int sum = 0; 
        
        while (number != -999) { 
            sum += number; 
            number = in.nextInt(); 
        } 
        
        System.out.println("Sum: " + sum); 


        /*
            question 2:
        */
        System.out.print("Enter a number: "); 
        int height = in.nextInt(); 
        
        for (int currentRow = 0; currentRow < height; currentRow++) { 
            for (int currentCol = 0; currentCol < height; currentCol++) { 
                System.out.print("*"); 
            } 

            System.out.println(); 
        } 

        /*
            question 3:
        */
        System.out.print("Enter a number: "); 
        int myNumber = in.nextInt(); 
 
        boolean isPrimaryNumber = true; 
        
        for (int currentDivider = 2; currentDivider <= myNumber / 2 && isPrimaryNumber; currentDivider++) 
        { 
            if (myNumber % currentDivider == 0) { 
                isPrimaryNumber = false; 
            } 
        } 
        
        if (isPrimaryNumber) { 
            System.out.println(myNumber + " is a prime number"); 
        } else { 
            System.out.println(myNumber + " is not a prime number"); 
        } 


        /*
            question 4:
        */
        System.out.println("Enter a fibonacci index"); 
        int fiboIndex = in.nextInt(); 
        long currentFiboNumber = 1, firstFiboNumber = 1, secondFiboNumber = 1; 
        
        for (int currentFiboIndex = 3; currentFiboIndex <= fiboIndex; currentFiboIndex++) { 
            currentFiboNumber = firstFiboNumber + secondFiboNumber; 
            firstFiboNumber = secondFiboNumber; 
            secondFiboNumber = currentFiboNumber; 
        } 
        
        System.out.println("The fibonacci value at index " + fiboIndex + " is " + currentFiboNumber);


        /*
            question 5:
        */
        for (int currentRow = 1; currentRow <= 10; currentRow++) { 
            for (int currentCol = 1; currentCol <= 10; currentCol++) { 
                System.out.print(currentRow * currentCol + "\t"); 
            } 
        
            System.out.println(); 
        } 
    }
}
