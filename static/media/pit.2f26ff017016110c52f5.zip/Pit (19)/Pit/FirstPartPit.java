import java.util.Scanner;

public class FirstPartPit {
    static final int MOVE_UP = 1;
    static final int MOVE_DOWN = 2;
    static final int MOVE_RIGHT = 3;
    static final int MOVE_LEFT = 4;
    static final int INVALID_MOVE = -999;
    static final int BOARD_SIZE = 10;

    static final String PLAYER_A = "A";
    static final String PLAYER_B = "B";
    static int aPlayerXloc;
    static int aPlayerYloc;
    static int bPlayerXloc;
    static int bPlayerYloc;
    static int winnersCarpetXloc;
    static int winnersCarpetYloc;
    static int winnersCarpetSize;

    public static void main(String[] args) {
        initializeValues();
        printBoard();

        boolean didGameEnd = false;

        while (!didGameEnd) {
                makeTurn(PLAYER_A);
                didGameEnd = didPlayerWin(aPlayerXloc, aPlayerYloc);
                printBoard();

                if (didGameEnd){
                    System.out.println("player " + PLAYER_A + " won this round!");
                } else {
                makeTurn(PLAYER_B);
                didGameEnd = didPlayerWin(bPlayerXloc, bPlayerYloc);
                printBoard();

                if (didGameEnd){
                        System.out.println("player " +  PLAYER_B + " won this round!");
                    }
                }
            }
        }

    private static void makeTurn(String player) {
        int playerMovement = getMoveDirection(player);
        final String BORDER_ERROR = "you cant go outside the board";

        if (playerMovement != INVALID_MOVE) {
            movePlayer(player, playerMovement);
        } else {
            System.out.println(BORDER_ERROR);
        }
    }

    private static void initializeValues() {
        final Scanner playerInput = new Scanner(System.in);

        System.out.println("WELCOME\nenter A player X location");
        aPlayerXloc = Integer.parseInt(playerInput.nextLine());
        System.out.println("enter A player Y location");
        aPlayerYloc = Integer.parseInt(playerInput.nextLine());
        System.out.println("enter B player X location");
        bPlayerXloc = Integer.parseInt(playerInput.nextLine());
        System.out.println("enter B player Y location");
        bPlayerYloc = Integer.parseInt(playerInput.nextLine());
        System.out.println("enter WINNERS CARPET top left location");
        winnersCarpetXloc = Integer.parseInt(playerInput.nextLine());
        winnersCarpetYloc = Integer.parseInt(playerInput.nextLine());
        System.out.println("enter WINNERS CARPET size");
        winnersCarpetSize = Integer.parseInt(playerInput.nextLine());
    }

    private static void printBoard() {
        final String WALL_SIGN = "#";
        final String WINNERS_CARPET_SIGN = "*";
        final String EMPTY_CELL_SIGN = " ";
        final int SAFETY_WALL_SIZE = 1;

        for (int xIndex = 0; xIndex < BOARD_SIZE + SAFETY_WALL_SIZE * 2; xIndex++) {
            for (int yIndex = 0; yIndex < BOARD_SIZE + SAFETY_WALL_SIZE * 2; yIndex++) {
                if (yIndex == 0
                        ||  xIndex == 0
                        || yIndex == BOARD_SIZE + SAFETY_WALL_SIZE
                        || xIndex == BOARD_SIZE + SAFETY_WALL_SIZE) {
                    System.out.print(WALL_SIGN);
                } else if (xIndex == aPlayerXloc && yIndex == aPlayerYloc) {
                    System.out.print(PLAYER_A);
                } else if (xIndex == bPlayerXloc && yIndex == bPlayerYloc) {
                    System.out.print(PLAYER_B);
                } else if (xIndex >= winnersCarpetXloc
                        && xIndex < winnersCarpetXloc + winnersCarpetSize
                        && yIndex >= winnersCarpetYloc
                        && yIndex < winnersCarpetYloc + winnersCarpetSize) {
                    System.out.print(WINNERS_CARPET_SIGN);
                } else {
                    System.out.print(EMPTY_CELL_SIGN);
                }
            }

            System.out.println();
        }
    }

    private static int getMoveDirection(String player) {
        final Scanner playerInput = new Scanner(System.in);
        final String MOVING_MENU = MOVE_UP + "-up "
                + MOVE_DOWN + "-down "
                + MOVE_RIGHT + "-right "
                + MOVE_LEFT + "-left";

        System.out.println("player " + player + "'s move");
        System.out.println(MOVING_MENU);
        int playerMovement = Integer.parseInt(playerInput.nextLine());

        if (player.equals(PLAYER_A)) {
            if (isMovingTowardsBorder(aPlayerXloc, aPlayerYloc, playerMovement)) {
                playerMovement = INVALID_MOVE;
            }
        } else {
            if (isMovingTowardsBorder(bPlayerXloc, bPlayerYloc, playerMovement)) {
                playerMovement = INVALID_MOVE;
            }
        }

        return playerMovement;
    }

    private static boolean isMovingTowardsBorder(int playerXloc, int playerYloc, int playerMovement) {
        final int BORDER_SIZE = 1;

        return playerXloc == BORDER_SIZE && playerMovement == MOVE_UP
                || playerXloc == BOARD_SIZE && playerMovement == MOVE_DOWN
                || playerYloc == BOARD_SIZE && playerMovement == MOVE_RIGHT
                || playerYloc == BORDER_SIZE && playerMovement == MOVE_LEFT;
    }

    private static void movePlayer(String player, int playerMovement) {
        final String BAD_INPUT_ERROR = "invalid option, please enter a number between 1 and 4";

        switch (playerMovement) {
            case MOVE_UP:
                if (player.equals(PLAYER_A)) {
                    aPlayerXloc--;
                } else {
                    bPlayerXloc--;
                }

                break;
            case MOVE_DOWN:
                if (player.equals(PLAYER_A)) {
                    aPlayerXloc++;
                } else {
                    bPlayerXloc++;
                }

                break;
            case MOVE_RIGHT:
                if (player.equals(PLAYER_A)) {
                    aPlayerYloc++;
                } else {
                    bPlayerYloc++;
                }

                break;
            case MOVE_LEFT:
                if (player.equals(PLAYER_A)) {
                    aPlayerYloc--;
                } else {
                    bPlayerYloc--;
                }

                break;
            default:
                System.out.println(BAD_INPUT_ERROR);

                break;
        }
    }

    private static boolean didPlayerWin(int playerXloc, int playerYloc) {
        return playerXloc >= winnersCarpetXloc
                && playerXloc < winnersCarpetXloc + winnersCarpetSize
                && playerYloc >= winnersCarpetYloc
                && playerYloc < winnersCarpetYloc + winnersCarpetSize;
    }
}
