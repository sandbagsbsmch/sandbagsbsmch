import java.util.Scanner;

public class SecondPartPit {
  static int aPlayerXloc;
  static int aPlayerYloc;
  static int bPlayerXloc;
  static int bPlayerYloc;
  static int winnersCarpetXloc;
  static int winnersCarpetYloc;
  static int winnersCarpetSize;

  public static void main(String[] args) {
    initializeValues();

    int aMinWinningMoves = calcWinningMoves(aPlayerXloc, aPlayerYloc);
    int bMinWinningMoves = calcWinningMoves(bPlayerXloc, bPlayerYloc);

    printBoard();

    if (aMinWinningMoves < bMinWinningMoves) {
      System.out.println("A player has the better chance");
    } else if (aMinWinningMoves > bMinWinningMoves){
      System.out.println("B player has the better chance");
    } else {
      System.out.println("Chances are equal for both players");
    }
  }

  private static void initializeValues() {
    final Scanner playerInput = new Scanner(System.in);
    System.out.println("WELCOME\nenter A player X location");
    aPlayerXloc = Integer.parseInt(playerInput.nextLine());
    System.out.println("enter A player Y location");
    aPlayerYloc = Integer.parseInt(playerInput.nextLine());
    System.out.println("enter B player X location");
    bPlayerXloc = Integer.parseInt(playerInput.nextLine());
    System.out.println("enter B player Y location");
    bPlayerYloc = Integer.parseInt(playerInput.nextLine());
    System.out.println("enter WINNERS CARPET top left location");
    winnersCarpetXloc = Integer.parseInt(playerInput.nextLine());
    winnersCarpetYloc = Integer.parseInt(playerInput.nextLine());
    System.out.println("enter WINNERS CARPET size");
    winnersCarpetSize = Integer.parseInt(playerInput.nextLine());
  }

  private static void printBoard() {
    final int BOARD_SIZE = 10;
    final int BORDER_SIZE = 1;
    final String WALL_SIGN = "#";
    final String PLAYER_A = "A";
    final String PLAYER_B = "B";
    final String WINNERS_CARPET_SIGN = "*";
    final String EMPTY_CELL_SIGN = " ";

    for (int xIndex = 0; xIndex < BOARD_SIZE + BORDER_SIZE * 2; xIndex++) {
      for (int yIndex = 0; yIndex < BOARD_SIZE + BORDER_SIZE * 2; yIndex++) {
        if (yIndex == 0
                || xIndex == 0
                || yIndex == BOARD_SIZE + BORDER_SIZE
                || xIndex == BOARD_SIZE + BORDER_SIZE) {
          System.out.print(WALL_SIGN);
        } else if (xIndex == aPlayerXloc && yIndex == aPlayerYloc) {
          System.out.print(PLAYER_A);
        } else if (xIndex == bPlayerXloc && yIndex == bPlayerYloc) {
          System.out.print(PLAYER_B);
        } else if (xIndex >= winnersCarpetXloc
                && xIndex < winnersCarpetXloc + winnersCarpetSize
                && yIndex >= winnersCarpetYloc
                && yIndex < winnersCarpetYloc + winnersCarpetSize) {
          System.out.print(WINNERS_CARPET_SIGN);
        } else {
          System.out.print(EMPTY_CELL_SIGN);
        }
      }

      System.out.println();
    }
  }

  private static int calcWinningMoves(int playerXloc, int playerYloc) {
    int minWinningMoves = 999;
    for (int xIndex = 0; xIndex < winnersCarpetSize; xIndex++) {
      for (int yIndex = 0; yIndex < winnersCarpetSize; yIndex++) {
        int currentDistance =
                Math.abs(xIndex + winnersCarpetXloc - playerXloc)
                        + Math.abs(yIndex + winnersCarpetYloc - playerYloc);

        minWinningMoves = Math.min(currentDistance, minWinningMoves);
      }
    }

    return minWinningMoves;
  }
}
