public class Main {
  public static void main(String[] args) {
    int a = 3;
    int b = 4;

    int first = a - b + 8;
    double second = (((Math.pow(a, b)) * 3) - 6) / 2;
    boolean third = first < 0;
    boolean fourth = third && first % 2 == 0;

    System.out.println("first: " + first);
    System.out.println("second: " + second);
    System.out.println("third: " + third);
    System.out.println("fourth: " + fourth);
  }
}
