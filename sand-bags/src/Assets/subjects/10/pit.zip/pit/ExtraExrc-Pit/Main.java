import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;



public class Main {
    public static void one() {
        Scanner myScanner = new Scanner(System.in);
        final int STOP_CODE = -999;

        System.out.println("Enter number to get his factorial (" + STOP_CODE + ") to stop):");
        int number = myScanner.nextInt();

        while (number != STOP_CODE) {
            if (number % 2 == 0) {
                int factorial = 1;

                for (int index = 1; index <= number; index++) {
                    factorial *= index;
                }

                System.out.println("Factorial of " + number + ": " + factorial);
            }

            System.out.println("Enter number to get his digits sum (" + STOP_CODE + ") to stop):");
            number = myScanner.nextInt();
        }
    }

    public static void two() {
        Scanner myScanner = new Scanner(System.in);
        final int STOP_CODE = -999;

        System.out.println("Enter number to get his digits sum (" + STOP_CODE + ") to stop):");
        int number = myScanner.nextInt();

        while (number != STOP_CODE) {
            int sum = 0;

            while (number > 0) {
                sum += number % 10;
                number /= 10;
            }

            System.out.println("Sum of all digits: " + sum);
            System.out.println("Enter number to get his digits sum (" + STOP_CODE + ") to stop):");
            number = myScanner.nextInt();
        }
    }

    public static void three() {
        Scanner scanner = new Scanner(System.in);

        final int LOWER_BOUND = 1;
        final int UPPER_BOUND = 100;
        int secretNumber = LOWER_BOUND + (int)(Math.random() * (UPPER_BOUND - LOWER_BOUND + 1));
        boolean win = false;

        System.out.println("Welcome to the Number Guessing Game!");
        System.out.println("Enter the number of possible guesses: ");
        int maxAttempts = scanner.nextInt();

        System.out.println("I'm thinking of a number between " + LOWER_BOUND + " and " + UPPER_BOUND + ".");
        System.out.println("You have " + maxAttempts + " attempts to guess the number.");

        for (int attempt = 1; attempt <= maxAttempts && !win; attempt++) {
            System.out.print("Attempt #" + attempt + ", enter your guess: ");
            int guess = scanner.nextInt();

            if (guess < LOWER_BOUND || guess > UPPER_BOUND) {
                System.out.println("Your guess is out of bounds.");
            } else if (guess < secretNumber) {
                System.out.println("Try a higher number.");
            } else if (guess > secretNumber) {
                System.out.println("Try a lower number.");
            } else {
                System.out.println("Congratulations! You guessed the number " + secretNumber + " correctly in " + attempt + " attempts.");
                win = true;
            }

            if (attempt == maxAttempts) {
                System.out.println("Sorry, you've used all your attempts. The correct number was " + secretNumber + ".");
            }
        }
    }

    public static void four() {
        Scanner myScanner = new Scanner(System.in);
        System.out.println("Enter number to check if it is palindrome:");

        int number = myScanner.nextInt();
        int originalNumber = number;
        int reversedNumber = 0;

        while (number > 0) {
            reversedNumber = reversedNumber * 10 + (number % 10);
            number /= 10;
        }

        if (originalNumber == reversedNumber) {
            System.out.println(originalNumber + " is a palindrome");
        } else {
            System.out.println(originalNumber + " is not a palindrome");
        }
    }

    public static void five() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the length of the triangle: ");
        int numRows = scanner.nextInt();

        for (int i = 1; i <= numRows; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print("*");
            }

            System.out.println();
        }
    }

    public static void six() {
        Scanner scanner = new Scanner(System.in);
        int count = 0;
        int equalCount = 0;
        int perfectCount = 0;

        System.out.println("Enter two numbers: ");
        int num1 = scanner.nextInt();
        int num2 = scanner.nextInt();

        while (num2 * -1 != num1) {
            count += 2;

            if (num2 == num1) {
                equalCount++;
            }

            if (((num1 % 2 == 0 && num2 % 3 == 0) || (num2 % 2 == 0 && num1 % 3 == 0)) &&
                    ((num1 * num1 < num2 / 2) || (num2 * num2 < num1 / 2)) && (num1 * num2 < 1000)) {
                perfectCount++;
            }

            System.out.println("Enter two numbers: ");
            num1 = scanner.nextInt();
            num2 = scanner.nextInt();
        }

        System.out.println("count = " + count);
        System.out.println("equal numbers amount = " + equalCount);
        System.out.println("perfect pairs = " + perfectCount);
    }

    public static void main(String[] args) {
    }
}