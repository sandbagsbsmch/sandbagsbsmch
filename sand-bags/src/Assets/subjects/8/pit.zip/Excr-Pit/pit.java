package com.company;

import java.util.Scanner;

public class Main {

  public static void main(String[] args) {

    // 1
    Scanner input = new Scanner(System.in);

    System.out.println("Enter number:");
    int number = input.nextInt();

    int unitsDigit  = number % 10;

    int answer;

    if (unitsDigit >= 5) {
      answer = number + 10 - unitsDigit;
    } else {
      answer = number - unitsDigit;
    }

    System.out.println("The rounded answer is " + answer);

    // 2
    Scanner input = new Scanner(System.in);

    System.out.println("Enter first number:");
    int firstNumber = input.nextInt();

    System.out.println("Enter second number:");
    int secondNumber = input.nextInt();

    if ((firstNumber % secondNumber) == 0 || (secondNumber % firstNumber) == 0) {
      System.out.println("Is factor");
    } else {
      System.out.println("Isnt factor");
    }

    // 3
    Scanner input = new Scanner(System.in);

    System.out.println("Enter your grade");
    int grade = input.nextInt();

    if (grade < 0) {
      System.out.println("Grade must be greater than 0");
    } else if (grade < 56) {
      System.out.println("Failed");
    } else if (grade < 70) {
      System.out.println("Almost enough");
    } else if (grade < 80) {
      System.out.println("Passable");
    } else if (grade < 90) {
      System.out.println("Good");
    } else if (grade < 95) {
      System.out.println("Very good");
    } else {
      System.out.println("Excellent");

      if (grade > 100) {
        System.out.println("You got " + (grade - 100) + " extra points");
      }
    }

    // 4
    Scanner input = new Scanner(System.in);

    System.out.println("Enter museum capability:");
    int museumCapacity = input.nextInt();

    System.out.println("Enter amount of groups:");
    int groupsAmount = input.nextInt();

    System.out.println("Enter group size:");
    int groupSize = input.nextInt();

    final int ESCORTS = 2;
    int requiredCapacity = groupsAmount * (groupSize + ESCORTS);

    if (requiredCapacity > museumCapacity) {
      System.out.println(
          "Not enough space, "
              + (requiredCapacity - museumCapacity)
              + " + people don't have place");
    } else {
      System.out.println("There is enough place");
    }

    // 5
    Scanner input = new Scanner(System.in);

    final int WINTER = 1;
    final int SPRING = 2;
    final int SUMMER = 3;
    final int FALL = 4;

    System.out.println("Enter average temperature: ");
    int averageTemperature = input.nextInt();

    System.out.println("Enter season code: ");
    System.out.println(WINTER + " winter");
    System.out.println(SPRING + " spring");
    System.out.println(SUMMER + " summer");
    System.out.println(FALL + " fall");
    int yearCode = input.nextInt();

    int expectedTemperature = averageTemperature;

    switch (yearCode) {
      case WINTER:
        {
          final int APPROVE = 1;
          final int DECLINE = 0;

          System.out.println("Is winter rainy?");
          System.out.println(APPROVE + " - yes");
          System.out.println(DECLINE + " - no");
          int answer = input.nextInt();

          if (answer == APPROVE) {
            expectedTemperature -= 7;
          } else {
            expectedTemperature -= 5;
          }

          break;
        }
      case SPRING:
        {
          expectedTemperature *= 0.9;

          break;
        }
      case SUMMER:
        {
          System.out.println("Please enter humidity");
          int humidity = input.nextInt();

          if (humidity < 60) {
            expectedTemperature += 8;
          } else {
            expectedTemperature += 12;
          }

          break;
        }
    }

    System.out.println(expectedTemperature);

    // 6
    Scanner input = new Scanner(System.in);

    final int MIN_VALUE = 1;
    final int MAX_VALUE = 999;
    final int GAME_DIGIT = 7;

    System.out.println("Please enter number between " + MIN_VALUE + " and " + MAX_VALUE);

    int number = input.nextInt();
    int digit = number % 10;
    int tens = (number / 10) % 10;
    int hundreds = number / 100;

    if ((number > MAX_VALUE) || (number < MIN_VALUE)) {
      System.out.println("Invalid input");
    } else if (((number % GAME_DIGIT) == 0)
        || (digit == GAME_DIGIT)
        || (tens == GAME_DIGIT)
        || (hundreds == GAME_DIGIT)) {
      System.out.println("BOOM");
    } else {
      System.out.println("NOT BOOM");
    }
  }
}
