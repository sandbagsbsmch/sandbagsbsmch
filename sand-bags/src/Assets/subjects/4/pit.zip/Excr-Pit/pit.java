public class Main {
    public static void main(String[] args) {

        // This is an example of a comment
        System.out.println("Name: Nadav Krashin");
        System.out.println("Age: " + 20);
        System.out.println("Favorite pet: Monkey");
    }
}