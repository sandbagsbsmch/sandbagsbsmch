import java.util.Scanner;

public class Pit {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter username");
        String username = scanner.nextLine();

        System.out.println("Enter age");
        int age = Integer.parseInt(scanner.nextLine());

        System.out.println("Enter weight");
        double weight = Double.parseDouble(scanner.nextLine());

        System.out.println("Enter full name");
        String fullName = scanner.nextLine();

        System.out.println("username: " + username + "\n" +
                "age: " + age + "\n"  +
                "weight: " + weight + "\n" +
                "fullName: " + fullName);
    }
}
