import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        final int CALCULATE_AGE_CODE = 1;
        final int CALCULATE_WEIGHT_CODE = 2;
        final int GET_STRING_LENGTH_CODE = 3;
        final int GET_SUM_CODE = 4;
        final int EXIT_CODE = 5;

        System.out.println("Welcome to the calculator");
        System.out.println("-------------");
        System.out.println("To calculate your age in days press " + CALCULATE_AGE_CODE);
        System.out.println("To calculate weight in tones press " + CALCULATE_WEIGHT_CODE);
        System.out.println("To calculate length of string if contains a press " + GET_STRING_LENGTH_CODE);
        System.out.println("To calculate sum of two double numbers press " + GET_SUM_CODE);
        System.out.println("For exit press " + EXIT_CODE);

        Scanner reader = new Scanner(System.in);
        int input = reader.nextInt();

        while (input != EXIT_CODE) {
            switch (input) {
                case CALCULATE_AGE_CODE:
                    System.out.println("Enter your age in years: ");
                    convertYearsToDays(reader.nextInt());

                    break;
                case CALCULATE_WEIGHT_CODE:
                    System.out.println("Enter weight in tones: ");
                    convertTonesToKilograms(reader.nextInt());

                    break;
                case GET_STRING_LENGTH_CODE:
                    final String CONTAINED_SUBSTRING = "a";
                    doesStringContain(CONTAINED_SUBSTRING);

                    break;
                case GET_SUM_CODE:
                    System.out.println("enter first number: ");
                    double firstNumber = reader.nextDouble();
                    System.out.println("enter second number: ");
                    double secondNumber = reader.nextDouble();
                    System.out.println(getSum(firstNumber, secondNumber));

                    break;
                default:
                    break;
            }

            System.out.println("Welcome to the calculator");
            System.out.println("-------------");
            System.out.println("To calculate your age in days press " + CALCULATE_AGE_CODE);
            System.out.println("To calculate weight in tones press " + CALCULATE_WEIGHT_CODE);
            System.out.println("To calculate length of string if contains a press " + GET_STRING_LENGTH_CODE);
            System.out.println("To calculate sum of two double numbers press " + GET_SUM_CODE);
            System.out.println("For exit press " + EXIT_CODE);
            input = reader.nextInt();
        }

        System.out.println("Bye Bye");
    }
    
    public static void convertYearsToDays(int yearsOfLife) {
        System.out.println(yearsOfLife * 365);
    }

    public static int convertTonesToKilograms(int tones) {
        int weightInKilograms = tones * 1000;
        System.out.println(weightInKilograms);

        return weightInKilograms;
    }

    public static void doesStringContain(String substring) {
        final int NOT_CONTAINED = 999;

        Scanner reader = new Scanner(System.in);
        System.out.println("Enter your full name: ");
        String fullName = reader.nextLine();

        if (fullName.contains(substring)) {
            System.out.println(fullName.length());
        } else {
            System.out.println(NOT_CONTAINED);
        }
    }

    public static double getSum(double firstNumber, double secondNumber) {
        return Math.pow(firstNumber + secondNumber, 4);
    }
}
